# epys-web-service
 A python library created to extract data from EPİAŞ's epys services.


I am creating this library voluntarily. That's why I didn't add all the methods. I will try to add more functions over time.
