# epys-web-service
 A python library created to extract data from EPİAŞ's epys services.
